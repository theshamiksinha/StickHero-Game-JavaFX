package com.example.newgame;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

import static com.example.newgame.MainPage.scoreList;
import static com.example.newgame.MainPage.serialize;

public class EndGameController implements ScoreObserver {

    @FXML
    public Pane EndGameRoot;
    @FXML
    public Circle restartButton;
    @FXML
    public Circle reviveButton;
    @FXML
    public Circle homeButton;
    @FXML
    public Label myScore;
    @FXML
    public Label bestScore;
    @FXML
    public Label cherryScore;

    private int scoreValue;
    private int bestScoreValue;
    private int cherryScoreValue;

    public int getScoreValue() {
        return scoreValue;
    }

    public int getBestScoreValue() {
        return bestScoreValue;
    }

    public int getCherryScoreValue() {
        return cherryScoreValue;
    }

    public void setScore(int score) {
        this.scoreValue = score;
        scoreList.add(score);
    }

    public void setScoreLabel(int score) {
        myScore.setText(String.valueOf(score));
    }

    public void setCherryScoreValue(int cherryScoreValue) {
        this.cherryScoreValue = cherryScoreValue;
    }

    public void setCherryScore(int cherryScore) {
        this.cherryScore.setText(String.valueOf(cherryScore));
    }

    public int setBestScore() throws Exception {
        this.bestScoreValue = scoreList.stream().mapToInt(v -> v).max().orElseThrow(Exception::new);
        return this.bestScoreValue;

    }
    public void setBestScoreLabel(int score) { bestScore.setText(String.valueOf(bestScoreValue));
    }
    public void homeButtonClicked(MouseEvent mouseEvent) throws IOException {

        this.goToHome();

    }

    public void reviveButtonClicked(MouseEvent mouseEvent) throws IOException {

        this.revivePlayer();
    }

    public void restartButtonClicked(MouseEvent mouseEvent) throws IOException {

        this.restartGame();

        serialize();
    }


    public void goToHome() throws IOException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MainPage.fxml"));

            Parent mainGameRoot = fxmlLoader.load();
            MainPageController mainPlayController = fxmlLoader.getController();
            mainPlayController.playSoundOnRestart();
            EndGameRoot.getChildren().setAll(mainGameRoot);

        } catch (IOException e) {
            e.printStackTrace();
        }

        serialize();
    }

    public void restartGame() throws IOException {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GamePlay.fxml"));

            Parent GamePlayRoot = fxmlLoader.load();
            EndGameRoot.getChildren().setAll(GamePlayRoot);

            GamePlayController gamePlayController = fxmlLoader.getController();
            gamePlayController.restartPositionSet();
            gamePlayController.playSoundOnRestart();

            gamePlayController.shiftScoreBoard();
            gamePlayController.shiftCherryCount();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void revivePlayer() throws IOException {

        if(this.getScoreValue() >= 3){

            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("GamePlay.fxml"));

                Parent GamePlayRoot = fxmlLoader.load();
                EndGameRoot.getChildren().setAll(GamePlayRoot);

                GamePlayController gamePlayController = fxmlLoader.getController();
                gamePlayController.restartPositionSet();
                gamePlayController.playSoundOnRestart();

                gamePlayController.shiftScoreBoard();
                gamePlayController.shiftCherryCount();
                gamePlayController.setScoreOnRevive(this.getScoreValue()- 3);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void updateScore(int score) {

        this.setScore(score);

    }
}
