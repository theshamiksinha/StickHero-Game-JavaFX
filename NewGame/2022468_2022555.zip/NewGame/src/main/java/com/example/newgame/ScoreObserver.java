package com.example.newgame;

public interface ScoreObserver {

    void updateScore(int score);
}
