package com.example.newgame;

public interface GameElements {

    public double getPositionX();
    public double getPositionY();
}
