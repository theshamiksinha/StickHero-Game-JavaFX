package com.example.newgame;

public class GameMenu {

    private int score;

    public int getScore(){
        return this.score;
    }

    public void resumeGame(){

        // resume where you left

    }
    public void quitGame(){

        // stop and go back to main menu

    }
    public void restartGame(){

        // restart from beginning

    }


}
